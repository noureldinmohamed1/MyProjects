#ifndef _3X3X_O_H
#define _3X3X_O_H

#include "bits\stdc++.h"
#include "BoardGame_Classes.h"


class _3x3X_O_Board:public Board<char> {
public:
    _3x3X_O_Board();
    bool update_board(int x , int y , char symbol) override;
    void display_board() override;
    bool is_win() override;
    bool is_draw() override;
    bool game_is_over() override;
    char getcell(int x, int y);
};


class _3x3X_O_Player : public Player<char> {
public:
    _3x3X_O_Player(string name, char symbol);
    void getmove(int& x, int& y);

};


class _3x3X_O_Random_Player : public RandomPlayer<char>{
public:
    _3x3X_O_Random_Player(string name, char symbol);
    void getmove(int &x, int &y);
};


// ----- 3x3_X_O_Tic_Tac_Toe Implementation -----


_3x3X_O_Board::_3x3X_O_Board()
{
    this->rows = this->columns = 3;
    this->board = new char*[this->rows];
    for (int i = 0; i < this->rows; ++i)
    {
        this->board[i] = new char[this->columns];
        for (int j = 0; j < this->columns; ++j)
        {
            this->board[i][j] = '1' + j + (3*i);
        }
    }
    this->n_moves = 0;
}


bool _3x3X_O_Board::update_board(int x, int y, char symbol) {
    if(x >= 0 && x <= 2 && y >= 0 && y <= 2 && this->board[x][y] >= '1' && this->board[x][y] <= '9')
    {
        this->board[x][y] = symbol;
        this->n_moves++;
        return 1;
    }
    return 0;
}



void _3x3X_O_Board::display_board()
{
    cout << "\n+---+---+---+\n";
    for (int i = 0; i < this->rows; ++i)
    {
        for (int j = 0; j < this->columns; ++j)
        {
            if(!j)
                cout << "|";
            cout << " " << this->board[i][j] << " |";
        }
        cout << endl;
        cout << "+---+---+---+\n";
    }
    cout << endl;
}



bool _3x3X_O_Board::is_win()
{
    // Check rows and columns
    for (int i = 0; i < this->rows; i++)
    {
        if ((this->board[i][0] == this->board[i][1] && this->board[i][1] == this->board[i][2] && (this->board[i][0] == 'X' || this->board[i][0] == 'O')) ||
            (this->board[0][i] == this->board[1][i] && this->board[1][i] == this->board[2][i] && (this->board[0][i] == 'X' || this->board[0][i] == 'O')))
            return 1;
    }

    // Check diagonals
    if ((this->board[0][0] == this->board[1][1] && this->board[1][1] == this->board[2][2] && (this->board[0][0] == 'X' || this->board[0][0] == 'O')) ||
        (this->board[0][2] == this->board[1][1] && this->board[1][1] == this->board[2][0] && (this->board[0][2] == 'X' || this->board[0][2] == 'O')))
        return 1;

    return 0;
}



bool _3x3X_O_Board::is_draw() {
    return (this->n_moves == 9 && !is_win());
}



bool _3x3X_O_Board::game_is_over() {
    return (is_win() || is_draw());
}


char _3x3X_O_Board::getcell(int x, int y)
{
    return this->board[x][y];
}


// ----- 3x3_X_O_Tic_Tac_Toe_Player Implementation -----



_3x3X_O_Player::_3x3X_O_Player(string name, char symbol) : Player(name, symbol) {}


void _3x3X_O_Player::getmove(int& x, int& y)
{
    cout << "\nPlease, enter a number of an empty cell:\n";
    int i;
    cin >> i;
    i--;
    x = i / 3 , y = i % 3;
}


// ----- 3x3_X_O_Tic_Tac_Toe_Random_Player Implementation -----


_3x3X_O_Random_Player::_3x3X_O_Random_Player(string name, char symbol) : RandomPlayer(symbol)
{
    this->dimension = 3;
    this->name = name;
    srand(static_cast<unsigned int>(time(0)));
}


void _3x3X_O_Random_Player::getmove(int& x, int& y) {
    x = rand() % this->dimension;
    y = rand() % this->dimension;
}







#endif //_3X3X_O_H

