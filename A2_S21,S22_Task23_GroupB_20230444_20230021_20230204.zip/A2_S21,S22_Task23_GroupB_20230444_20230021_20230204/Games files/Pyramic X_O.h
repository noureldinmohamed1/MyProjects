#ifndef PYRAMIC_X_O_H
#define PYRAMIC_X_O_H

#include <bits\stdc++.h>
#include "BoardGame_Classes.h"
using namespace std;


class Pyramic_X_O_Board : public Board <char> {
public:
    Pyramic_X_O_Board ();
    bool update_board (int x , int y , char symbol);
    void display_board () ;
    bool is_win() ;
    bool is_draw();
    bool game_is_over();
};


class Pyramic_X_O_Player : public Player <char> {
public:
    Pyramic_X_O_Player(string name, char symbol);
    void getmove(int& x, int& y);
};



class Pyramic_X_O_Random_Player : public RandomPlayer <char> {
public:
    Pyramic_X_O_Random_Player(string name, char symbol);
    void getmove(int& x, int& y);
};


// ----- Pyramic_X_O_Board Implementation -----


Pyramic_X_O_Board::Pyramic_X_O_Board()
{
    this->rows = 3;
    this->columns = 5;
    this->board = new char*[this->rows];
    for (int i = 0; i < this->rows; ++i)
    {
        this->board[i] = new char[this->columns];
    }
    int cnt = 1;
    for (int i = 0; i < this->rows; ++i)
    {
        for (int j = 2-i; j <= 2+i; ++j)
        {
            this->board[i][j] = '0' + cnt++;
        }
    }
}



bool Pyramic_X_O_Board::update_board(int x, int y, char symbol) {
    if(((x == 0 && y == 2) || (x == 1 && y >= 1 && y <= 3) || (x == 2 && y >= 0 && y <= 5)) && this->board[x][y] >= '1' && this->board[x][y] <= '9')
    {
        this->board[x][y] = symbol;
        this->n_moves++;
        return 1;
    }
    return 0;
}



void Pyramic_X_O_Board::display_board()
{
    cout << "---------------------\n";
    for (int i = 0; i < this->rows; ++i)
    {
        for (int j = 0; j < this->columns; ++j)
        {
            if(j >= 2-i && j <= 2+i)
            {
                if(j == 2-i)
                    cout << "|";
                cout << " " << this->board[i][j] << " |";
            }
            else
            {
                cout << string(4,' ');
            }
        }
        cout << endl;
    }
    cout << "---------------------\n";
}



bool Pyramic_X_O_Board::is_win() {
    // Check Diagonals
    if(this->board[0][2] == this->board[1][1] && this->board[0][2] == this->board[2][0] && this->board[0][2] > '9')
        return 1;
    if(this->board[0][2] == this->board[1][3] && this->board[0][2] == this->board[2][4] && this->board[0][2] > '9')
        return 1;

    // Check Columns
    if(this->board[0][2] == this->board[1][2] && this->board[0][2] == this->board[2][2] && this->board[0][2] > '9')
        return 1;

    // Check Rows
    if(this->board[1][1] == this->board[1][2] && this->board[1][1] == this->board[1][3] && this->board[1][1] > '9')
        return 1;
    for (int i = 0; i < 3; ++i)
    {
        bool eq = 1;
        for (int j = i+1; j < i+3; ++j)
        {
            if(this->board[2][j] != this->board[2][i])
                eq = 0;
        }
        if(eq)
            return 1;
    }
    return 0;
}



bool Pyramic_X_O_Board::is_draw() {
    return (this->n_moves == 9 && !is_win());
}



bool Pyramic_X_O_Board::game_is_over() {
    return (is_win() || is_draw());
}

// ----- Pyramic_X_O_Player Implementation -----


Pyramic_X_O_Player::Pyramic_X_O_Player(string name, char symbol) : Player<char>(name,symbol){}


void Pyramic_X_O_Player::getmove(int &x, int &y)
{
    cout << "\nPlease, enter a number of an empty cell:\n";
    int i;
    cin >> i;
    if(i == 1)
        x = 0 , y = 2;
    else if(i >= 2 && i <= 4)
        x = 1 , y = i - 1;
    else
        x = 2 , y = i - 5;
}


// ----- Pyramic_X_O_Random_Player Implementation -----


Pyramic_X_O_Random_Player::Pyramic_X_O_Random_Player(string name, char symbol) : RandomPlayer<char>(symbol)
{
    this->name = name;
    srand(static_cast<unsigned int>(time(0)));
}



void Pyramic_X_O_Random_Player::getmove(int &x, int &y)
{
    x = rand() % 3;
    y = rand() % 5;
}




#endif //PYRAMIC_X_O_H
