#ifndef _5X5X_O_H
#define _5X5X_O_H
#include "bits/stdc++.h"
#include "BoardGame_Classes.h"

int _5x5_n_moves;


class X_O_5x5_Board:public Board<char> {
public:
    X_O_5x5_Board ();
    bool update_board (int x , int y , char symbol);
    void display_board () ;
    bool is_win() ;
    bool is_draw();
    bool game_is_over();

};


class X_O_5x5_Player : public Player<char> {
public:
    X_O_5x5_Player (string name, char symbol);
    void getmove(int& x, int& y) ;

};


class X_O_5x5_Random_Player : public RandomPlayer<char>{
public:
    X_O_5x5_Random_Player (string name, char symbol);
    void getmove(int &x, int &y) ;
};

///////////////////////// IMPLEMENTATION //////////

#include <bits/stdc++.h>
using namespace std;

// Constructor for X_O_5x5_Board

X_O_5x5_Board::X_O_5x5_Board() {
    this->rows = this->columns = 5;
    this->board = new char* [this->rows];
    for (int i = 0; i < this->rows; ++i) {
        this->board[i] = static_cast<char *>(new char[this->columns]);
        for (int j = 0; j < this->columns; ++j) {
            this->board[i][j] = 0;
        }
    }
    this->n_moves = 0;
}


bool X_O_5x5_Board::update_board(int x, int y, char mark) {
    if (this->n_moves == 24)
    {
        this->n_moves = _5x5_n_moves = 25;
        return true;
    }
    if (!(x < 0 || x >= this->rows || y < 0 || y >= this->columns) && (this->board[x][y] == 0|| mark == 0)) {
        if (mark == 0){
            this->n_moves--;
            this->board[x][y] = 0;
        }
        else {
            this->n_moves++;
            this->board[x][y] = toupper(mark);
        }
        _5x5_n_moves = this->n_moves;

        return true;
    }
    return false;
}


void X_O_5x5_Board::display_board() {
    if (this->n_moves == 25)
        return;
    cout << "Current board :" <<endl;
    cout << "---------------";
    for (int i = 0; i < this->rows; i++) {
        cout << "\n| ";
        for (int j = 0; j < this->columns; j++) {
            if (!this->board[i][j])
            {
                cout << "  " << (5*i + j + 1 < 10 ? " " : "") << 5*i + j + 1 << "   | ";
            }
            else
            {
                cout << "   "  << this->board[i][j] << "   | ";
            }
        }
        cout << "\n----------------------------------------------";
    }
    cout << endl;
}


bool X_O_5x5_Board::is_win() {
    auto isValid = [&](int x , int y) -> bool{
        return x >= 0 && x < this->rows && y >= 0 && y < this->columns;
    };

    const int dx[] = {0 , 1 , 1 , -1};
    const int dy[] = {1 , 1 , 0 , 1};
    int p1 = 0 , p2 = 0;

    auto count = [&](){
        for (int i = 0; i < this->rows; ++i) {
            for (int j = 0; j < this->columns; ++j) {
                char symbol = this->board[i][j];
                for (int k = 0; k < 4; ++k) {
                    int nx1 = i + dx[k] , ny1 = j + dy[k];
                    int nx2 = i + 2*dx[k] , ny2 = j + 2*dy[k];
                    if (isValid(nx1 , ny1) && isValid(nx2 , ny2) && this->board[nx1][ny1] == symbol && this->board[nx2][ny2] == symbol && this->board[nx2][ny2] != 0)
                    {
                        if (symbol == 'X')
                        {
                            p1++;
                        }
                        else
                        {
                            p2++;
                        }
                    }
                }
            }
        }
    };

    if (this->n_moves < 24)
    {
        return false;
    }
    else if (this->n_moves == 24)
    {
        count();
        return p2 > p1;
    }
    else
    {
        count();
        return p2 < p1;
    }
}


bool X_O_5x5_Board::is_draw() {
    return this->n_moves == 25;
}


bool X_O_5x5_Board::game_is_over() {
    return this->n_moves == 25;
}


// Constructor for X_O_5x5_Player

X_O_5x5_Player::X_O_5x5_Player(string name, char symbol) : Player<char>(name, symbol) {}


void X_O_5x5_Player::getmove(int& x, int& y) {
    if (_5x5_n_moves == 24)
        return;
    cout << '\n' << name << ", Please enter your position (1 to 25): ";
    int pos; cin >> pos;
    x = (pos-1) / 5;
    y = (pos-1) % 5;
}

// Constructor for X_O_5x5_Random_Player

X_O_5x5_Random_Player::X_O_5x5_Random_Player(string name, char symbol) : RandomPlayer<char>(symbol) {
    this->dimension = 5;
    this->name = name;
    srand(static_cast<unsigned int>(time(0)));
}


void X_O_5x5_Random_Player::getmove(int& x, int& y) {
    x = rand() % this->dimension;
    y = rand() % this->dimension;
}

#endif //_5X5X_O_H
