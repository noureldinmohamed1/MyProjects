#ifndef _3X3_INV_X_O_H
#define _3X3_INV_X_O_H

#include "BoardGame_Classes.h"

bool winner;
int inv_3x3_n_moves;


class X_O_3x3_inv_Board:public Board<char> {
public:
    X_O_3x3_inv_Board ();
    bool update_board (int x , int y , char symbol);
    void display_board () ;
    bool is_win() ;
    bool is_draw();
    bool game_is_over();

};


class X_O_3x3_inv_Player : public Player<char> {
public:
    X_O_3x3_inv_Player (string name, char symbol);
    void getmove(int& x, int& y) ;

};


class X_O_3x3_inv_Random_Player : public RandomPlayer<char>{
public:
    X_O_3x3_inv_Random_Player (string name, char symbol);
    void getmove(int &x, int &y) ;
};


///////////////////////// IMPLEMENTATION //////////

#include <bits/stdc++.h>
using namespace std;

// Constructor for X_O_3x3_inv_Board

X_O_3x3_inv_Board::X_O_3x3_inv_Board() {
    this->rows = this->columns = 3;
    this->board = new char* [this->rows];
    for (int i = 0; i < this->rows; ++i) {
        this->board[i] = static_cast<char *>(new char[this->columns]);
        for (int j = 0; j < this->columns; ++j) {
            this->board[i][j] = 0;
        }
    }
    this->n_moves = 0;
}


bool X_O_3x3_inv_Board::update_board(int x, int y, char mark) {
    if (winner)
    {
        inv_3x3_n_moves++;
        return true;
    }
    if (!(x < 0 || x >= this->rows || y < 0 || y >= this->columns) && (this->board[x][y] == 0|| mark == 0)) {
        if (mark == 0){
            this->n_moves--;
            this->board[x][y] = 0;
        }
        else {
            this->n_moves++;
            this->board[x][y] = toupper(mark);
        }
        inv_3x3_n_moves = this->n_moves;
        return true;
    }
    return false;
}




void X_O_3x3_inv_Board::display_board() {
    if (winner)
    {
        return;
    }
    cout << "Current board :" <<endl;
    cout << "---------------";
    for (int i = 0; i < this->rows; i++) {
        cout << "\n| ";
        for (int j = 0; j < this->columns; j++) {
            if (!this->board[i][j])
            {
                cout << "  " << 3*i + j + 1 << "   | ";
            }
            else
            {
                cout << "  " << this->board[i][j] << "   | ";
            }
        }
        cout << "\n-------------------------";
    }
    cout << endl;
}


bool X_O_3x3_inv_Board::is_win() {

    if (winner && inv_3x3_n_moves != this->n_moves)
    {
        return true;
    }

    auto isValid = [&](int x , int y) -> bool{
        return x >= 0 && x < this->rows && y >= 0 && y < this->columns;
    };

    const int dx[] = {0 , 1 , 1 , -1};
    const int dy[] = {1 , 1 , 0 , 1};

    for (int i = 0; i < this->rows; ++i) {
        for (int j = 0; j < this->columns; ++j) {
            char symbol = this->board[i][j];
            for (int k = 0; k < 4; ++k) {
                int nx1 = i + dx[k] , ny1 = j + dy[k];
                int nx2 = i + 2*dx[k] , ny2 = j + 2*dy[k];
                if (isValid(nx1 , ny1) && isValid(nx2 , ny2) && this->board[nx1][ny1] == symbol && this->board[nx2][ny2] == symbol && this->board[nx2][ny2] != 0)
                {
                    winner = true;
                    return false;
                }
            }
        }
    }
    return false;
}


bool X_O_3x3_inv_Board::is_draw() {
    return !is_win() && this->n_moves == (winner ? 10 : 9);
}


bool X_O_3x3_inv_Board::game_is_over() {
    return is_win() || is_draw();
}


// Constructor for X_O_3x3_inv_Player

X_O_3x3_inv_Player::X_O_3x3_inv_Player(string name, char symbol) : Player(name, symbol) {}


void X_O_3x3_inv_Player::getmove(int& x, int& y) {
    if (winner)
    {
        return;
    }
    cout << '\n' << name << ", Please enter your position (1 to 9): ";
    int pos; cin >> pos;
    x = (pos-1) / 3;
    y = (pos-1) % 3;
}

// Constructor for X_O_Random_Player

X_O_3x3_inv_Random_Player::X_O_3x3_inv_Random_Player(string name, char symbol) : RandomPlayer(symbol) {
    this->dimension = 3;
    this->name = name;
    srand(static_cast<unsigned int>(time(0)));
}


void X_O_3x3_inv_Random_Player::getmove(int& x, int& y) {
    x = rand() % this->dimension;
    y = rand() % this->dimension;
}


#endif //_3X3_INV_X_O_H
