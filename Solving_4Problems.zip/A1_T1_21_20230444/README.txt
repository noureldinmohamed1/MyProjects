The description of the files for problem 12:
--------------------------------------------------
1- .txt files must be in the same folder with .cpp file.
2- MyList file contains the words I collected and its values.
3- There are 4 files with (testcase) name, each of them contains a paragraph includes some of the words which in MyList file.
4- If you want to create your test case, create a file with extension (.txt) in the same folder and put your sentences in it.


How to use the files in the program:
-------------------------------------
1- When you run the program and the menu appeared, choose 5 (problem 12).
2- The program will ask you to enter a name of a file with (.txt) extension.
3- You can write the name of one of my testcase files or the name of your created file (if created).
4- After that the program will display all details which required in the problem 12.