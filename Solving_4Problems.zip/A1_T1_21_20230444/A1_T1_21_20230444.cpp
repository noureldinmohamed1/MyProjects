// File: A1_T1_21_20230444.cpp
// Purpose: Solving problems 3, 6, 9 and 12 from assignment 1 task 1
// Author: Nour Eldin Mohamed Amin
// Section: S21
// ID: 20230444
// TA: None
// Date: 12 Oct 2024
// Detailed explanation of the file and how program works:
// 1- Once you run the program, the menu will appear
// 2- The menu includes all required problems and an exit option
// 3- After choosing an option, the instructions will help you to use the program step by step
// 4- For problem 12 and how to use files, it will be explained in the README file


#include <bits/stdc++.h>
using namespace std;


// the valid function
bool valid(string s)
{
    // if the string s contains trailing zeros or if it is empty return false
    if (s[0] == '0' || s.empty())
        return false;

    // loop for each character in the string and return false if it is not from 0 to 9
    for (auto ch : s)
    {
        if (ch > '9' || ch < '0')
            return false;
    }
    return true;
}


// For problem 3
// initialize a global variable to store the length of delimiter in it
int del_sz;
// the split function
vector<string> split(string target, string delimiter)
{
    // initialize a vector to store the words in the target string
    vector<string>ret;

    // initialize start variable
    int start = 0;

    // loop for each character in the target string
    for (int i = 0 ; i < target.size() ; ++i) {

        // initialize a check variable containing characters from target string
        // starting from index i with the same length of the delimiter
        string check = target.substr(i , del_sz);

        // check if check variable equals to the delimiter
        if (check == delimiter)
        {
            // push characters from index start to index i-1 to ret vector
            ret.push_back(target.substr(start , i-start));
            // increase i by the length of the delimiter -1 because the loop will increase that 1
            i+=del_sz-1;
            // assign start variable to i+1
            start = i+1;
        }
        // if I reach to the last index of the target string
        else if (i == target.size()-1)
        {
            // push characters from index start to the end to ret vector and break
            ret.push_back(target.substr(start , i-start+1));
            break;
        }
    }

    // return the ret vector
    return ret;
}


// For problem 6 part 1
// initialize a global variable to store the binary representation in it
string binary;
// the binaryPrint function
static void binaryPrint(int n)
{
    // the base case if the number becomes 0
    if (n == 0)
    {
        // check if the binary string is empty that means that n is 0
        if (binary.empty())
            binary = '0' + binary;
        return;
    }
    // check if n is odd or even
    if (n&1)
        // push front 1 if n is odd
        binary = '1' + binary;
    else
        // push front 0 if n is even
        binary = '0' + binary;
    // call the binaryPrint function recursively and pass n/2 as a parameter
    binaryPrint(n/2);
}


// For problem 6 part 2
// initialize a global variable to store the length of the suffix string plus the length of k
int tot_sz;
// initialize a global vector to store all possible combinations in it
vector<string>answer;
// the body of numbers function
static void numbers(string suffix , int k)
{
    // the base case when ind equal to k
    if (suffix.size() == tot_sz)
    {
        // push suffix string to comp vector and return
        answer.push_back(suffix);
        return;
    }
    // call numbers function recursively two times
    // first time with the next index and push 0 to suffix
    // second time with the next index and push 1 to suffix
    numbers(suffix+'0' , k);
    numbers(suffix+'1' , k);
}


// For problem 9
// the bears function
static bool bears(int n)
{
    // check if n equal 42 return true;
    if (n == 42)
    {
        return true;
    }
    // check if n less than 42 return false;
    else if (n < 42)
    {
        return false;
    }
    // check if n is divisible by 2
    if (n % 2 == 0)
    {
        // check if I can reach 42 bears from n/2 bears then return true
        if (bears(n/2))
            return true;
    }
    // check if n is divisible by 3 or by 4
    if (n % 3 == 0 || n % 4 == 0)
    {
        // calc the multiplication of the last 2 digits of n
        int minus = (n%10) * ((n/10)%10);
        // check if I can reach 42 bears from n-minus bears then return true
        if(bears(n-minus))
            return true;
    }
    // check if n is divisible by 5
    if (n % 5 == 0)
    {
        // check if I can reach 42 bears from n-42 bears then return true
        if (bears(n-42))
            return true;
    }
    // if none of these options then return false
    return false;
}



int main()
{
    // print a welcome message
    cout << "Welcome to our program." <<endl;

    // initialize choice string
    string choice = "0";
    while (choice != "6")
    {
        // display the menu
        cout << "--- The Menu ---" <<endl;
        cout << "1- Split a string. (Problem 3)" <<endl;
        cout << "2- Binary representation. (Problem 6 part 1)" <<endl;
        cout << "3- Prefix and suffix. (Problem 6 part 2)" <<endl;
        cout << "4- 42 bears ? (Problem 9)" <<endl;
        cout << "5- Phishing Scanner. (Problem 12)" <<endl;
        cout << "6- Exit the program." <<endl;

        // ask the user to enter his choice
        cout << "Please, enter your choice :" <<endl;
        getline(cin , choice);

        // check the validity of the choice
        while (!valid(choice) || stoi(choice) < 1 || stoi(choice) > 6)
        {
            // if not a valid choice print an error message and ask the user again
            cout << "Your choice must be an integer number from 1 to 6 !" <<endl;
            cout << "Please, enter your choice again :" <<endl;
            getline(cin , choice);
        }

        // if choice equals 1
        if (choice == "1")
        {
            // initialize a target and a delimiter variables
            string target , delimiter;

            // take the target from the user
            cout << "Please enter the target :" <<endl;
            getline(cin , target);

            // take the delimiter from the user
            cout << "Please enter the delimiter :" <<endl;
            getline(cin , delimiter);

            // assign the size of the delimiter to del_sz variable
            del_sz = delimiter.size();

            // initialize the vector that will contain the answer
            vector<string>ans;

            // make answer vector equals to the split function
            // and passing the target and the delimiter strings as parameters
            ans = split(target , delimiter);

            // loop for each element in the ans vector
            cout << "The strings in the target are :" <<endl;
            for (string s : ans)
            {
                // print each element in the ans vector
                cout << s <<endl;
            }

            // print a separator
            cout << "----------------------------------------------------------------------" <<endl;
        }

        // if choice equal 2
        else if (choice == "2")
        {
            // ask the user to enter a positive integer number and store it in variable n
            cout << "Please, enter a positive integer number :" <<endl;
            string n;
            getline(cin , n);

            // check the validity of the number
            while (!valid(n))
            {
                // if not valid print an error message and ask the user again
                cout << "Your input must be a positive integer number without trailing zeroes !" <<endl;
                cout << "Please, enter a positive integer number again :" <<endl;
                getline(cin , n);
            }

            // clear binary because it is a global variable
            binary.clear();

            // call binaryPrint function and passing n as an integer as a parameter
            binaryPrint(stoi(n));

            // print the binary representation of the integer
            cout << "The binary representation of " << n << " is : " << binary << '.' <<endl;

            // print a separator
            cout << "----------------------------------------------------------------------" <<endl;
        }

        // if choice equals 3
        else if (choice == "3")
        {
            // ask the user to enter the prefix string
            string prefix;
            cout << "Please enter the prefix string :" <<endl;
            getline(cin , prefix);

            // lambda function to check if the prefix string is a binary string
            auto check = [&]() -> bool {
                for (auto ch : prefix)
                {
                    if (ch != '1' && ch != '0')
                    {
                        return false;
                    }
                }
                return true;
            };

            // check the validity of the binary string
            while (!check())
            {
                // if not valid print an error message and ask the user again
                cout << "The prefix string must be binary (consists of zeroes and ones only) !" <<endl;
                cout << "Please enter the prefix string again : " <<endl;
                getline(cin , prefix);
            }

            // ask the user to enter the length of the suffix
            cout << "Please enter the length of the suffix string :" <<endl;
            string k;
            getline(cin , k);

            // check the validity of the number
            while (!valid(k))
            {
                // if not valid print an error message and ask the user again
                cout << "Your input must be a positive integer number without trailing zeroes !" <<endl;
                cout << "Please enter the length of the suffix string again : " <<endl;
                getline(cin , k);
            }

            // assign tot_sz to the length of the prefix string plus the length of the suffix (k)
            tot_sz = prefix.size() + stoi(k);

            // clear answer vector because it is a global vector
            answer.clear();

            // call numbers function with parameters prefix and k (the length of the suffix)
            // and store all combinations in the answer vector
            numbers(prefix , stoi(k));

            // loop for each string s in the answer vector
            cout << "The prefix followed by the " << pow(2 , stoi(k)) <<  " possible suffixes :" <<endl;
            for (auto s : answer)
            {
                // print the string s
                cout << s <<endl;
            }

            // print a separator
            cout << "----------------------------------------------------------------------" <<endl;
        }

        // if choice equals 4
        else if (choice == "4")
        {
            // ask the user to enter the number of bears and store it in variable n
            cout << "Please, enter the number of bears :" <<endl;
            string n;
            getline(cin , n);

            // check the validity of the number
            while (!valid(n))
            {
                // if not valid print an error message and ask the user again
                cout << "Your input must be a positive integer number without trailing zeroes !" <<endl;
                cout << "Please, enter the number of bears again :" <<endl;
                getline(cin , n);
            }

            // check if I can reach 42 bears or not and print the suitable message
            if (bears(stoi(n)))
            {
                cout << "It is possible to win the bears game starting with " << n << " bears." <<endl;
            }
            else
            {
                cout << "It is not possible to win the bears game starting with " << n << " bears." <<endl;
            }

            // print a separator
            cout << "----------------------------------------------------------------------" <<endl;
        }

        // if choice equals 5
        else if (choice == "5")
        {
            // preprocessing
            // initialize a file stream to read from it
            ifstream MyWords;
            // open the file in the reading mode
            MyWords.open("MyList.txt" , ios::in);
            // initialize a map to store the value of each word
            map<string , int>WordToValue;

            // while not reaching the end of the file
            while (!MyWords.eof())
            {
                // take a word and its value from the file and store in the map
                string word; MyWords >> word;
                int value; MyWords >> value;
                WordToValue[word] = value;
            }
            // close the file
            MyWords.close();


            // ask the user to enter the name of the file
            cout << "Please, enter the name of your file (e.g. name.txt) :" <<endl;
            string name;
            getline(cin , name);
            // initialize a file stream to read from it
            ifstream file;
            // open the file in the reading mode
            file.open(name , ios::in);

            // lambda function to check the validity of the name of the file
            auto chkFilename = [&]() -> int {
                // if the size of the name less the 5 or the extention is wrong return 0
                if (name.size() < 5 || name.substr(name.size()-4) != ".txt")
                    return 0;
                // if the file can not be opened return 1
                else if (!file)
                    return 1;
                // return 2 if the name is valid
                return 2;
            };

            // while the name is not valid ask the user again and print the suitable error message
            while (chkFilename() != 2)
            {
                if (chkFilename() == 0)
                {
                    cout << "The name of the file must be in the given form !" <<endl;
                }
                else if (chkFilename() == 1)
                {
                    cout << "Something went wrong while trying to open the file (" << name << "), may be the file does not exist." <<endl;
                }
                cout << "Please, enter the name of your file again (e.g. name.txt) :" <<endl;
                getline(cin , name);
                file.open(name , ios::in);
            }

            // if the name is valid print a message
            cout << "The file is opened successfully." <<endl;

            // initialize a variable to store the total points of the words in it
            int Tot_Pts = 0;
            // initialize a map to store the frequency of each word
            map<string , int>freq;

            // while not reaching the end of the file
            while (!file.eof())
            {
                // take word from the file
                string s; file >> s;
                // if the word ends with any punctuation mark remove the punctuation mark
                if (!isalpha(s.back()))
                    s.erase(s.begin()+s.size()-1);
                if (isupper(s[0]))
                    s[0] = tolower(s[0]);
                // if the word exist in the map (which initialized in preprocessing)
                if (WordToValue.find(s) != WordToValue.end())
                    // increase the frequency of the word by 1 and add the value of the word to the total points
                    freq[s]++ , Tot_Pts += WordToValue[s];
            }
            // close the file
            file.close();

            // print each appeared word , its frequency , its value and its total points
            cout << "--------------------------------------------------------------------------------" <<endl;
            cout << left << setw(20) << "The word" << '|' << setw(20) << "The value" << '|' << setw(20) << "The frequency" << '|' << setw(20) << "The total points" <<endl;
            cout << "--------------------------------------------------------------------------------" <<endl;
            for (auto [word , f] : freq)
            {
                cout << left << setw(20) << word << '|' << setw(20) << WordToValue[word] << '|' << setw(20) << f << '|' << setw(20) << f*WordToValue[word] <<endl;
            }
            cout << "--------------------------------------------------------------------------------" <<endl;

            // print total points of all appeared words
            cout << "The total points for all words in the file is " << Tot_Pts << '.' <<endl;

            // print a separator
            cout << "----------------------------------------------------------------------" <<endl;
        }

        // if choice equals 6
        else if (choice == "6")
        {
            cout << "Thank you for using our program." <<endl;
        }
    }
    return 0;
}