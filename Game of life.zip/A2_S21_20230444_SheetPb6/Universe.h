#include <bits/stdc++.h>
using namespace std;

class Universe {
private:
    int length , width;
    vector<vector<char>>grid;
    vector<vector<int>>neighbours;
public:
    Universe();
    void set_Len(int l);
    void set_Wid(int w);
    int get_Len();
    int get_Wid();
    void initialize();
    void set_cell_alive(int x , int y);
    void count_neighbours();
    bool is_valid_cell(int x , int y);
    bool is_alive_cell(int x , int y);
    void reset();
    void next_generation();
    void display();
    void run(int steps , bool stepBYstep , bool clear_console);
    ~Universe();
};


