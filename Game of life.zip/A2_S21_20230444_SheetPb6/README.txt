Introduction
------------
It was a very good problem , it took a lot of time from me to cover all options and handling all errors that can be happen from the user so, I ask you to try all of these options and test them.
--------------------------------------------------------------------------------------------------

The explanation of the game
---------------------------
The universe of this game is a grid of square cells that could have one of two states: dead or alive. 
Every cell interacts with its adjacent neighbors, with the following transactions occurring on every step:
1) Any live cell with fewer than two live neighbors dies, as if caused by underpopulation.
2) Any live cell with two or three live neighbors lives on to the next generation.
3) Any live cell with more than three live neighbors dies, as if by overpopulation.
4) Any dead cell with exactly three live neighbors becomes a live cell, as if by reproduction.
--------------------------------------------------------------------------------------------------

Running the game
----------------
Once you run the file it will ask you to choose the way you want to initialize the grid from 4 given options:

1) Load from a file ==> which allows you to load the grid from a file (you must follow the next notes so the file can be accepted).

-Note 1: the file must consist of 0s (died cells) and 1s (alive cells) only, except the first 2 numbers they will considered as the length and the width of the grid.
-Note 2: if the file does not initialize all the cells, not initialized cells will considered as died cells.
-Note 3: if the file initialized cells more than the cells of the grid, the additional cells will be discarded.

2) Make it random ==> which initialize a random length and width and ask you to enter the percentage of alive cells then, they will be chosen randomly.

3) Choose from the fixed sizes ==> which let you choose from 3 given sizes then, it will ask you to choose the way you want to initialize the grid either randomly or manually.
-if your choice is randomly, it will ask you to enter the percentage of alive cells then, they will be chosen randomly.
-if your choice is manually, it will display all positions in the grid and ask you to enter all the positions you want to make them alive cells.

4) Enter a specific size ==> which allows you to enter the length and the width of the grid, then it will ask you to choose the way you want to initialize the grid either randomly or manually as it explained in the last option.


After initialized the grid, the menu will be displayed which also have 4 options:

1) Initialize a new grid ==> it will give you the last 4 options again.

2) Display the current grid ==> it will display the current grid.

3) Run the game ==> it allows you to run the game throw many options:
-First it will ask you to enter how many generations you want to run.
-Second it will ask you how do you want to display the generations either display the final generation or display generation by generation.
-Third ==> it will ask you if you want to clear the console after each generation:
*if yes (please, run the game from .exe file so the console can be cleared).
After each generation it will ask you if you want to display the next generation or to stop here,
if you choose to stop it will stop , display the menu again and the grid will be updated.

Note: in the last generation or if you choose to run the final generation, the two options (run the next generation and stop) will do the same thing which is to stop displaying the grid and display the menu again.

4) Exit ==> it will exit the game.

Thank you.