#include <bits/stdc++.h>
#include "Universe.h"

using namespace std;


Universe::Universe() {
    length = width = 0;
    grid = vector<vector<char>>(0 , vector<char>(0 , '0'));
    neighbours = vector<vector<int>>(0 , vector<int>(0 , 0));
}

void Universe::set_Len(int l) {
    length = l;
}

void Universe::set_Wid(int w) {
    width = w;
}

int Universe::get_Len() {
    return length;
}

int Universe::get_Wid() {
    return width;
}

void Universe::initialize() {
    grid = vector<vector<char>>(length , vector<char>(width , '0'));
    neighbours = vector<vector<int>>(length , vector<int>(width , 0));
}

void Universe::set_cell_alive(int x, int y) {
    grid[x][y] = '1';
}

bool Universe::is_valid_cell(int x, int y) {
    return x >= 0 && x < length && y >= 0 && y < width;
}

bool Universe::is_alive_cell(int x, int y) {
    return is_valid_cell(x , y) && grid[x][y] == '1';
}

// to iterate on all neighbours
int dx[8] = {0 , 0 , -1 , 1 , -1 , 1 , 1 , -1};
int dy[8] = {1 , -1 , 0 , 0 , 1 , 1 , -1 , -1};

void Universe::count_neighbours() {
    for (int i = 0; i < length; ++i) {
        for (int j = 0; j < width; ++j) {
            for (int k = 0; k < 8; ++k) {
                int nx = i + dx[k] , ny = j + dy[k];
                if (is_valid_cell(nx , ny) && grid[nx][ny] == '1')
                {
                    neighbours[i][j]++;
                }
            }
        }
    }
}

void Universe::reset() {
    Universe();
}

/*
    The Rules:
    Any live cell with fewer than two live neighbors dies
    Any live cell with two or three live neighbors lives on to the next generation
    Any live cell with more than three live neighbors dies
    Any dead cell with exactly three live neighbors becomes a live cell
 */
void Universe::next_generation() {
    neighbours = vector<vector<int>>(length , vector<int>(width , 0));
    count_neighbours();
    for (int i = 0; i < length; ++i) {
        for (int j = 0; j < width; ++j) {
            if (grid[i][j] == '1')
            {
                if (neighbours[i][j] < 2 || neighbours[i][j] > 3)
                {
                    grid[i][j] = '0';
                }
            }
            else if (neighbours[i][j] == 3)
            {
                grid[i][j] = '1';
            }
        }
    }
}

void Universe::display() {
    cout << string(width , '-') << " The grid " << string(width , '-') <<endl;
    for (int i = 0; i < length; ++i) {
        for (int j = 0; j < width; ++j) {
            cout << grid[i][j] << ' ';
        }
        cout <<endl;
    }
    cout << string(width*2 + 10 , '-') <<endl;
}

void Universe::run(int steps , bool stepBYstep , bool clear_console) {
    auto stop = []() -> int{
        cout << "What do you want to do now ?" <<endl;
        cout << "1) Display the next generation." <<endl;
        cout << "2) Stop." <<endl;
        cout << "Please, enter your choice:" <<endl;
        string ch;
        getline(cin , ch);
        while (ch != "1" && ch != "2")
        {
            cout << "Error, your choice must be 1 or 2." <<endl;
            cout << "Please, enter your choice:" <<endl;
            getline(cin , ch);
        }
        return ch == "2";
    };
    if (clear_console)
    {
        system("cls");
    }
    int counter = 1 , tempSteps = steps;
    while (steps--)
    {
        next_generation();
        if (stepBYstep)
        {
            cout << "Generation #" << counter++ <<endl;
            cout << "----------------" <<endl;
            display();
            if (stop())
            {
                if (clear_console)
                {
                    system("cls");
                }
                break;
            }
            if (clear_console)
            {
                system("cls");
            }
        }
    }
    if (!stepBYstep)
    {
        cout << "After " << tempSteps << " generations." <<endl;
        cout << "-----------------------" <<endl;
        display();
        stop();
        if (clear_console)
        {
            system("cls");
        }
    }
}

Universe::~Universe() {

}





