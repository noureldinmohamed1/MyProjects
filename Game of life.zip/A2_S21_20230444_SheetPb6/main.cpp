#include <bits/stdc++.h>
#include "Universe.h"

using namespace std;

void menu()
{
    cout << "-------- The Menu --------" <<endl;
    cout << "1) Initialize a new grid." <<endl;
    cout << "2) Display the current grid." <<endl;
    cout << "3) Run the game." <<endl;
    cout << "4) Exit." <<endl;
    cout << "Please, Enter your choice:" <<endl;
}

void menu_new_grid()
{
    cout << "How do you want to initialize the grid?" <<endl;
    cout << "1) Load from a file." <<endl;
    cout << "2) Make it random." <<endl;
    cout << "3) Choose from the fixed sizes." <<endl;
    cout << "4) Enter a specific size." <<endl;
    cout << "Please, Enter your choice:" <<endl;
}

bool is_valid_choice(string ch , int num_of_choices)
{
    if (ch.size() == 1)
    {
        return ch[0] - '0' > 0 && ch[0] - '0' <= num_of_choices;
    }
    return false;
}

bool is_valid_file(Universe &uni , ifstream &file)
{
    int l = -1 , w = -1;
    string length; file >> length;
    if (length.empty())
    {
        return false;
    }
    for (int i = 0; i < length.size(); ++i) {
        if (length[i]-'0' < 0 || length[i]-'0' > 9)
        {
            return false;
        }
    }
    l = stoi(length);
    string width; file >> width;
    if (width.empty())
    {
        return false;
    }
    for (int i = 0; i < width.size(); ++i) {
        if (width[i]-'0' < 0 || width[i]-'0' > 9)
        {
            return false;
        }
    }
    w = stoi(width);

    if (l <= -1 || w <= -1)
    {
        return false;
    }
    uni.set_Len(l);
    uni.set_Wid(w);
    uni.initialize();
    string indices;
    while (!file.eof())
    {
        string x; file >> x;
        indices+=x;
    }
    int ind = 0;
    for (int i = 0; i < l && ind < indices.size(); ++i) {
        for (int j = 0; j < w && ind < indices.size(); ++j) {
            if (isspace(indices[ind]))
            {
                continue;
            }
            if (indices[ind] != '0' && indices[ind] != '1')
            {
                return false;
            }
            if (indices[ind] == '1')
            {
                uni.set_cell_alive(i , j);
            }
            ind++;
        }
    }
    return true;
}

bool is_valid_bounded_num(string num , int lb = 0 , int ub = 1e4)
{
    if (num.empty())
        return false;
    for (int i = 0; i < num.size(); ++i) {
        if (num[i]-'0' < 0 || num[i]-'0' > 9)
        {
            return false;
        }
    }
    return stoi(num) >= 0 && stoi(num) <= ub;
}

void init_random_cells(Universe &uni)
{
    cout << "Please, enter the percentage of alive cells:" <<endl;
    string perc;
    getline(cin , perc);
    while (!is_valid_bounded_num(perc , 0 , 100))
    {
        cout << "Error, your choice must be an integer number from 0 to 100." <<endl;
        cout << "Please, enter the percentage of the alive cell:" <<endl;
        getline(cin , perc);
    }
    double number_of_alive = (uni.get_Len()*uni.get_Wid()) * (double)(stod(perc) / 100);
    srand(time(nullptr));
    for (int i = 0; i < number_of_alive; ++i) {

        int row = rand()%uni.get_Len();
        int column = rand()%uni.get_Wid();
        while(uni.is_alive_cell(row , column))
        {
            row = rand()%uni.get_Len();
            column = rand()%uni.get_Wid();
        }
        uni.set_cell_alive(row , column);
    }
}

void init_alive_cells(Universe &uni)
{
    cout << "How do you want to initialize the alive cells ?" <<endl;
    cout << "1) Randomly." <<endl;
    cout << "2) Manually." <<endl;
    cout << "Please, enter your choice:" <<endl;
    string initcells;
    getline(cin , initcells);
    while (!is_valid_choice(initcells , 2))
    {
        cout << "Error, your choice must be 1 or 2." <<endl;
        cout << "Please, enter your choice:" <<endl;
        getline(cin , initcells);
    }
    if (initcells == "1")
    {
        init_random_cells(uni);
    }
    else
    {
        cout << "The indices of the grid:" <<endl;
        cout << "------------------------" <<endl;
        int length = uni.get_Len() , width = uni.get_Wid();
        for (int i = 1; i <= length; ++i) {
            for (int j = 1; j <= width; ++j) {
                cout << j + ((i-1)*width) << ' ';
            }
            cout <<endl;
        }
        cout << "Please, enter the indices you want (separated by white space):" <<endl;
        string indices;
        getline(cin , indices);
        int Acc_ind = 0 , Rej_ind = 0;
        string index;
        for (int i = 0; i < indices.size(); ++i) {
            if (indices[i] == ' ' && !index.empty())
            {
                if (is_valid_bounded_num(index , 1 , length*width))
                {
                    int ind = stoi(index) , row = (ind+width-1)/width - 1 , column = (ind+width-1)%width;
                    if (!uni.is_alive_cell(row , column))
                    {
                        uni.set_cell_alive(row , column);
                        Acc_ind++;
                    }
                    else
                    {
                        Rej_ind++;
                    }
                }
                else
                {
                    Rej_ind++;
                }
                index = "";
            }
            else if (indices[i] != ' ')
            {
                index+=indices[i];
            }
        }
        if (!index.empty())
        {
            if (is_valid_bounded_num(index , 1 , length*width))
            {
                int ind = stoi(index) , row = (ind+width-1)/width - 1 , column = (ind+width-1)%width;
                if (!uni.is_alive_cell(row , column))
                {
                    uni.set_cell_alive(row , column);
                    Acc_ind++;
                }
                else
                {
                    Rej_ind++;
                }
            }
            else
            {
                Rej_ind++;
            }
        }
        cout << "Accepted indices = " << Acc_ind <<endl;
        cout << "Rejected indices = " << Rej_ind <<endl;
    }
}

void init_new_grid(Universe &uni , bool init_grid , bool first_time)
{
    while (!init_grid)
    {
        string ch;
        menu_new_grid();
        getline(cin , ch);
        while (!is_valid_choice(ch,  4))
        {
            cout << "Error, your choice must be an integer number from 1 to 4." <<endl;
            cout << "Please, Enter your choice:" <<endl;
            getline(cin , ch);
        }
        if (ch == "1")
        {
            ifstream file;
            string filename;

            cout << "Please, enter the name of your file (without extension):" <<endl;
            getline(cin , filename);
            filename += ".txt";
            file.open(filename , ios::in);
            while (!file)
            {
                cout << "Error, something went wrong while trying to open the file (maybe it does not exist)." <<endl;
                cout << "Please, enter the name of your file (without extension):" <<endl;
                getline(cin , filename);
                filename += ".txt";
                file.open(filename , ios::in);
            }
            cout << "File loaded successfully." <<endl;
            if (is_valid_file(uni , file))
            {
                init_grid = true;
                cout << "Accepted file." <<endl;
            }
            else {
                uni.reset();
                cout << "Rejected file (Read the notes in README file)." <<endl;
                if (!first_time)
                {
                    break;
                }
            }
        }
        else if (ch == "2")
        {
            srand(time(nullptr));
            int length = 1 + rand()%100;
            int width = 1 + rand()%100;
            uni.set_Len(length);
            uni.set_Wid(width);
            uni.initialize();
            cout << "The random length = " << length <<endl;
            cout << "The random width = " << width <<endl;
            init_random_cells(uni);
            init_grid = true;
        }
        else if (ch == "3")
        {
            cout << "The allowable sizes are (rows x columns):" <<endl;
            cout << "1) 20 x 50." <<endl;
            cout << "2) 30 x 30." <<endl;
            cout << "3) 20 x 20." <<endl;
            cout << "Please, enter your choice:" <<endl;
            string sizech;
            getline(cin , sizech);
            while (!is_valid_choice(sizech , 3))
            {
                cout << "Error, your choice must be an integer number from 1 to 3." <<endl;
                cout << "Please, enter your choice:" <<endl;
                getline(cin , sizech);
            }
            if (sizech == "1")
            {
                uni.set_Len(20);
                uni.set_Wid(50);
            }
            else if (sizech == "2")
            {
                uni.set_Len(30);
                uni.set_Wid(30);
            }
            else
            {
                uni.set_Len(20);
                uni.set_Wid(20);
            }
            uni.initialize();

            init_alive_cells(uni);

            init_grid = true;
        }
        else {
            cout << "Please, enter the length of the grid (the upper bound is 100 for better display):" <<endl;
            string len;
            getline(cin , len);
            while (!is_valid_bounded_num(len , 1 , 100))
            {
                cout << "Error, your input must be an integer number from 1 to 100." <<endl;
                cout << "Please, enter the length of the grid (the upper bound is 100 for better display):" <<endl;
                getline(cin , len);
            }
            cout << "Please, enter the width of the grid (the upper bound is 100 for better display):" <<endl;
            string wid;
            getline(cin , wid);
            while (!is_valid_bounded_num(wid , 1 , 100))
            {
                cout << "Error, your input must be an integer number from 1 to 100." <<endl;
                cout << "Please, enter the width of the grid (the upper bound is 100 for better display):" <<endl;
                getline(cin , wid);
            }
            uni.set_Len(stoi(len));
            uni.set_Wid(stoi(wid));
            uni.initialize();

            init_alive_cells(uni);

            init_grid = true;
        }
    }
    cout << "Grid initialized successfully." <<endl;
}

int main() {
    Universe uni;
    cout << "Welcome to Game Of Life game." <<endl;
    cout << "------------------------------" <<endl;
    init_new_grid(uni , false , true);


    while (true)
    {
        menu();
        string ch;
        getline(cin , ch);
        while (!is_valid_choice(ch,  4))
        {
            cout << "Error, your choice must be an integer number from 1 to 3." <<endl;
            cout << "Please, Enter your choice:" <<endl;
            getline(cin , ch);
        }
        if (ch == "1")
        {
            init_new_grid(uni , false , false);
        }
        else if (ch == "2")
        {
            uni.display();
        }
        else if (ch == "3")
        {
            cout << "Please, enter how many generations do you want to run:" <<endl;
            string steps;
            getline(cin , steps);
            while (!is_valid_bounded_num(steps))
            {
                cout << "Error, your input must be an integer number from 0 to 10000." <<endl;
                cout << "Please, enter how many generations do you want to run:" <<endl;
                getline(cin , steps);
            }
            cout << "How do you want to display the game ?" <<endl;
            cout << "1) Display the final generation." <<endl;
            cout << "2) Display generation by generation." <<endl;
            cout << "Please, enter your choice:" <<endl;
            string run;
            getline(cin , run);
            while (!is_valid_choice(run , 2))
            {
                cout << "Error, your choice must be 1 or 2." <<endl;
                cout << "Please, enter your choice:" <<endl;
                getline(cin , run);
            }

            cout << "Do you want to clear the console after each generation ?" <<endl;
            cout << "1) Yes." <<endl;
            cout << "2) No." <<endl;
            cout << "Please, enter your choice:" <<endl;

            string cons;
            getline(cin , cons);
            while (!is_valid_bounded_num(cons , 1 , 2))
            {
                cout << "Error, your choice must be 1 or 2." <<endl;
                cout << "Please, enter your choice:" <<endl;
                getline(cin , cons);
            }

            uni.run(stoi(steps) , run == "2" , cons == "1");
        }
        else {
            cout << "Thank you for playing my game." <<endl;
            return 0;
        }
    }

}
